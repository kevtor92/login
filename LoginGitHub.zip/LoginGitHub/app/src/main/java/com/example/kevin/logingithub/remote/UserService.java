package com.example.kevin.logingithub.remote;

import com.example.kevin.logingithub.model.User;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;


public interface UserService {

    @GET("user")
    Call<User> basicLogin(@Header("Authorization") String authToken);

}
